
package database;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;


public class Koneksi {
    static Connection con;
    static Statement stmt;
    static final String pbo = "jdbc:mysql://localhost/kel6_pbo";
    static String username = "root";
    static String password = "";

    public static Connection connect(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(pbo,username,password);
            stmt = con.createStatement(); 
            System.out.println("Koneksi Berhasil");
        } catch (Exception e) {
            System.out.println("Koneksi Gagal");
        }
        return con;
    }
    
//    public static void insert_user(String username, String password){
//        try {
//            String sql = "INSERT INTO user(username,password) VALUES('"+username+"','"+password+"')";
//            stmt = connect().createStatement();
//            stmt.execute(sql);
//            
//            
//            System.out.println("Tambah Data Berhasil");
//        } catch (Exception e) {
//            System.out.println("Tambah Data Gagal");
//        }  
//    }
//    public static void delete_user(String username){
//        try {
//            String sql = "DELETE FROM user WHERE username='"+username+"'";
//            stmt = connect().createStatement();
//            stmt.execute(sql);
//            
//            
//            System.out.println("Hapus Data Berhasil");
//        } catch (Exception e) {
//            System.out.println("Hapus Data Gagal");
//        }  
//    }    
//     public static void update_user(String username){
//        try {
//            String sql = "UPDATE TABLE user set username='"+username+"' WHERE username='"+username+"'";
//            stmt = connect().createStatement();
//            stmt.execute(sql);
//            
//            
//            System.out.println("Hapus Data Berhasil");
//        } catch (Exception e) {
//            System.out.println("Hapus Data Gagal");
//        }  
//    }     
//    public static void read_user(String username){
//        try {
//            String sql = "SELECT * FROM user WHERE username='"+username+"'";
//            stmt = connect().createStatement();
//            ResultSet rs = stmt.executeQuery(sql);
//            rs.next();
//            System.out.println("Username :"+rs.getString("username"));
//            System.out.println("Password :"+rs.getString("password"));
//            
//        } catch (Exception e) {
//            System.out.println("Ambil Data Gagal");
//        }  
//    }  
//    public static void read_user_all(){
//        try {
//            String sql = "SELECT * FROM user ";
//            stmt = connect().createStatement();
//            ResultSet rs = stmt.executeQuery(sql);
//            while(rs.next()){
//                System.out.println("Username :"+rs.getString("username"));
//                System.out.println("Password :"+rs.getString("password"));            
//            }
//        } catch (Exception e) {
//            System.out.println("Ambil Data Gagal");
//        }         
//    }    
    public static void main(String[] args) {
        connect();
//        insert_user("user1", "user");
//        delete_user("a");
//        read_user("user1");
    }
    
}
