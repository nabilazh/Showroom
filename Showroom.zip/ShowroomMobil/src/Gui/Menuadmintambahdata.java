package Gui;

import database.Koneksi;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.table.DefaultTableModel;


    public class Menuadmintambahdata extends javax.swing.JFrame {
    private void teks(){
        isi_id.setText("");
        isi_merk.setText("");
        isi_warna.setText("");    
        isi_harga.setText("");
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Menuadmintambahdata().setVisible(true);
            }
        });
    }
    
    public Menuadmintambahdata(){
        initComponents();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = getSize();
        setLocation(
        (screenSize.width - frameSize.width) / 2,
        (screenSize.height - frameSize.height) / 2);
    }
    public void Tambahdatamobil(){
        try {
            String sql = "INSERT INTO listmobil VALUES('"+isi_id.getText()+"', '"+isi_merk.getText()+"', '"+isi_warna.getText()+"', '"+isi_harga.getText()+"');";
            java.sql.Connection con = (Connection) Koneksi.connect();
            java.sql.Statement stmt = con.createStatement();
            java.sql.PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.execute();
            JOptionPane.showMessageDialog(null, "Data Mobil telah ditambahkan!");
            tampilkandata();
            teks();
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Data gagal ditambahkan!");
            JOptionPane.showMessageDialog(this, e.getMessage());
        }  
    }         
    
    public void tampilkandata(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Id Mobil");
        model.addColumn("Merk Mobil");
        model.addColumn("Warna");
        model.addColumn("Harga");
        
        try{
            int no = 1;
            String sql = "SELECT * From listmobil";
            java.sql.Connection con = (Connection) Koneksi.connect();
            java.sql.Statement stmt = con.createStatement();
            java.sql.ResultSet res = stmt.executeQuery(sql);
            
            while(res.next()){
                String[] data = {res.getString(1),res.getString(2),res.getString(3),res.getString(4)}; // eksekusi query
             model.addRow(data);
//                model.addRow(new Object[]{ res.getString(0),res.getString(1), res.getString(2), res.getString(3), res.getString(4)});
            }
            tabelmobil.setModel(model);
    }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    
            public void perbaruidata(){
        try{
            String sql = "UPDATE `listmobil` SET `id`='"+isi_id.getText()+"',`Merk`='"+isi_merk.getText()+"',"+ "`Warna`='"+isi_warna.getText()+"',`Harga`='"+isi_harga.getText()+"' WHERE id="+isi_id.getText();
            java.sql.Connection con = (Connection) Koneksi.connect();
            java.sql.Statement stmt = con.createStatement();
            java.sql.PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.execute();   
            JOptionPane.showMessageDialog(null, "Data Mobil Berhasil Diubah!");     
        }    
            catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }     
        tampilkandata();
           
    }
       
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        isi_id = new javax.swing.JTextField();
        isi_merk = new javax.swing.JTextField();
        isi_harga = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelmobil = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        isi_warna = new javax.swing.JTextField();
        bttambah = new javax.swing.JButton();
        bthapus = new javax.swing.JButton();
        btperbarui = new javax.swing.JButton();
        bttampilkan = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(183, 218, 230));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel1.setText("Tambah Data Mobil");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 21, -1, -1));

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel2.setText("Form Tambah Data ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, -1, -1));

        jLabel3.setText("ID");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 130, -1, -1));

        jLabel4.setText("Merk");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 170, -1, -1));

        jLabel5.setText("Harga");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 170, -1, -1));

        isi_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isi_idActionPerformed(evt);
            }
        });
        jPanel1.add(isi_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 127, 100, -1));

        isi_merk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isi_merkActionPerformed(evt);
            }
        });
        jPanel1.add(isi_merk, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 167, 100, -1));

        isi_harga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isi_hargaActionPerformed(evt);
            }
        });
        jPanel1.add(isi_harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 167, 90, -1));

        tabelmobil.setBackground(new java.awt.Color(233, 234, 206));
        tabelmobil.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Id", "Merk", "Warna", "Harga"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabelmobil);
        tabelmobil.getAccessibleContext().setAccessibleParent(tabelmobil);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, 550, 230));

        jLabel6.setText("Warna");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 130, -1, -1));

        isi_warna.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isi_warnaActionPerformed(evt);
            }
        });
        jPanel1.add(isi_warna, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 127, 90, -1));

        bttambah.setText("Tambah");
        bttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttambahActionPerformed(evt);
            }
        });
        jPanel1.add(bttambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 260, 80, -1));

        bthapus.setText("Hapus");
        bthapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bthapusActionPerformed(evt);
            }
        });
        jPanel1.add(bthapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, -1, -1));

        btperbarui.setText("Update");
        btperbarui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btperbaruiActionPerformed(evt);
            }
        });
        jPanel1.add(btperbarui, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 260, -1, -1));

        bttampilkan.setText("Tampilkan Data");
        bttampilkan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttampilkanActionPerformed(evt);
            }
        });
        jPanel1.add(bttampilkan, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 260, -1, -1));

        jButton1.setText("Keluar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 550, 100, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 608, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 584, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void isi_merkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isi_merkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isi_merkActionPerformed

    private void bttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttambahActionPerformed
        Tambahdatamobil();
    }//GEN-LAST:event_bttambahActionPerformed

    private void btperbaruiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btperbaruiActionPerformed
        perbaruidata();
    }//GEN-LAST:event_btperbaruiActionPerformed

    private void bthapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bthapusActionPerformed
        Hapusdatamobil();
    }//GEN-LAST:event_bthapusActionPerformed

    private void bttampilkanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttampilkanActionPerformed
        tampilkandata();
    }//GEN-LAST:event_bttampilkanActionPerformed

    private void isi_hargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isi_hargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isi_hargaActionPerformed

    private void isi_warnaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isi_warnaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isi_warnaActionPerformed

    private void isi_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isi_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isi_idActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
        Menuadmin lg = new Menuadmin();
        lg.setVisible(true);
        lg.pack();
        lg.setLocationRelativeTo(null);
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bthapus;
    private javax.swing.JButton btperbarui;
    private javax.swing.JButton bttambah;
    private javax.swing.JButton bttampilkan;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField isi_harga;
    private javax.swing.JTextField isi_id;
    private javax.swing.JTextField isi_merk;
    private javax.swing.JTextField isi_warna;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelmobil;
    // End of variables declaration//GEN-END:variables

    public void Hapusdatamobil(){
        try {
            String sql = "DELETE FROM `listmobil` WHERE id_Mobil="+isi_id.getText() ;
            java.sql.Connection con = (Connection) Koneksi.connect();
            java.sql.Statement stmt = con.createStatement();
            java.sql.PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.execute();
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
            tampilkandata();
            teks();
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }  
    }         
       
    }

