-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Des 2022 pada 08.38
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uaspbo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `listmobil`
--

CREATE TABLE `listmobil` (
  `Id_mobil` int(11) NOT NULL,
  `Merk` varchar(50) NOT NULL,
  `Warna` varchar(20) NOT NULL,
  `Harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `listmobil`
--

INSERT INTO `listmobil` (`Id_mobil`, `Merk`, `Warna`, `Harga`) VALUES
(1, 'BMW 4-Series', 'Biru Tua', 1200000000),
(2, 'BMW 6-Series', 'Putih', 1599000000),
(3, 'BMW 7-Series', 'Hitam', 1977000000),
(4, 'BMW 8-Series', 'Silver', 252700000),
(5, 'BMW M2', 'Putih', 1649000000),
(6, 'NEW HRV 1.5L S CVT', 'Abu-Abu', 378700000),
(7, 'NEW HRV 1.5L SE CVT', 'Maroon', 421400000),
(8, 'NEW HRV 1.5L TURBO RS CVT', 'Hitam', 529700000),
(9, 'NEW CRV PRESTIGE ', 'Putih', 685000000),
(10, 'HONDA ACCORD 1.5L TURBO', 'Abu-Abu', 832800000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbregis`
--

CREATE TABLE `tbregis` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `re-type password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbregis`
--

INSERT INTO `tbregis` (`username`, `password`, `re-type password`) VALUES
('refan', '123', '[C@1a4f388f'),
('ADMIN', '123', '[C@5f5a748a');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `listmobil`
--
ALTER TABLE `listmobil`
  ADD PRIMARY KEY (`Id_mobil`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
